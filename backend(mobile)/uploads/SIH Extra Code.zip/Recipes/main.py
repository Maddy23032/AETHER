from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from supabase import create_client, Client
import os
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

app = FastAPI(title="Low Oil Recipes API")
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)


# -----------------------------------------------------------
# Pydantic Models
# -----------------------------------------------------------

class Ingredient(BaseModel):
    name: str
    qty: str


class Step(BaseModel):
    __root__: List[str]


class Recipe(BaseModel):
    title: str
    description: str
    ingredients: List[Ingredient]
    steps: List[str]
    region: Optional[str]
    cuisine: Optional[str]
    diet_type: Optional[str]
    estimated_oil_ml: Optional[float]
    servings: Optional[int]
    difficulty: Optional[str]
    prep_time_min: Optional[int]
    cook_time_min: Optional[int]
    thumbnail_url: Optional[str]


class TempRecipe(Recipe):
    chef_name: Optional[str]
    chef_email: Optional[str]
    restaurant_name: Optional[str]


# -----------------------------------------------------------
# API ROUTES
# -----------------------------------------------------------

@app.get("/recipes")
def get_recipes(
    region: Optional[str] = None,
    cuisine: Optional[str] = None,
    diet_type: Optional[str] = None,
    max_oil: Optional[int] = None,
    difficulty: Optional[str] = None,
):
    query = supabase.table("recipes").select("*")

    if region:
        query = query.eq("region", region)
    if cuisine:
        query = query.eq("cuisine", cuisine)
    if diet_type:
        query = query.eq("diet_type", diet_type)
    if difficulty:
        query = query.eq("difficulty", difficulty)
    if max_oil:
        query = query.lte("estimated_oil_ml", max_oil)

    data = query.execute()
    return data.data


@app.get("/recipes/{id}")
def get_recipe(id: str):
    result = supabase.table("recipes").select("*").eq("id", id).execute()
    
    if not result.data:
        raise HTTPException(404, "Recipe not found")

    return result.data[0]


@app.get("/temp-recipes")
def get_temp_recipes():
    result = supabase.table("temp_recipes").select("*").execute()
    return result.data


@app.post("/temp-recipes")
def submit_temp_recipe(recipe: TempRecipe):
    data = supabase.table("temp_recipes").insert(recipe.dict()).execute()
    return {"message": "Submitted successfully", "id": data.data[0]["id"]}


# Health Check
@app.get("/")
def root():
    return {"status": "FastAPI Recipe Service Running"}
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080", "http://localhost:8081",  "http://localhost:8082"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
