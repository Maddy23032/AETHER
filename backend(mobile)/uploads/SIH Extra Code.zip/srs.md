#  **Layer 1 — Base-Level Features (Minimum Viable Product / Must-Have)**

These are the **essential features** your app must demonstrate to prove you can solve the problem.
Judges expect at least this layer to be fully functional.

---

## **1. User Onboarding & Profile**

* Sign in with phone (OTP) or email.
* Basic profile: age, region, preferred cuisine, health goals.

---

## **2. Oil Consumption Tracker (Core Feature)**

* Manual entry of daily oil usage (household-level).
* Visual indicators: progress bars, red/yellow/green warnings.
* Automatic weekly/monthly summary.

---

## **3. Awareness & Education**

* Short videos, infographics, and quiz modules about:

  * dangers of excess oil
  * recommended limits
  * healthier cooking methods
* Localized content (Hindi + English minimum).

---

## **4. Healthy Recipes (Low-Oil Suggestions)**

* Curated list of low-oil recipes.
* Categorized by:

  * region
  * cuisine
  * diet (veg, non-veg, diabetic-friendly)
* Step-by-step instructions.

---

## **5. Nudges & Notifications**

* Daily reminders to track oil usage.
* Alerts when consumption is above safe levels.
* Positive reinforcement when users stay within the limit.

---

## **6. Basic Admin Dashboard**

* Show aggregated charts:

  * number of users
  * average oil consumption
  * district/state breakdown (even if simulated)
* Simple heatmap or bar charts.

---

 This is the **absolute minimum set** required to demonstrate that your app can shift user behavior, provide awareness, and track consumption.

---

#  **Layer 2 — Secondary / Advanced Features (Good-to-Have for SIH Finals)**

These are advanced components that show technical depth and innovation.
Implement 2–4 of these depending on time.

---

## **1. AI-Powered Personalized Diet Recommendations**

* Suggest recipes based on:

  * user’s health parameters
  * region (e.g., Punjabi, South Indian, Bengali food)
  * daily/weekly oil consumption history
* AI chatbot for food guidance (simple LLM or custom model).

---

## **2. IoT Integration (Simulated or Real)**

* Smart oil-container/sensor or kitchen scale integration.
* Bluetooth or Wi-Fi API to auto-log oil usage.
* Even a simulated JSON input through your app is acceptable.

---

## **3. Restaurant/Canteen Certification System**

* Restaurants upload ingredients + oil content.
* You generate:

  * "Low Oil Certified" badge
  * Digital menu label (e.g., green/yellow indicator).
* Restaurant dashboard to submit dishes.

---

## **4. Blockchain Transparency Layer**

* Store certification records immutably.
* Validate restaurant claims.
* Simple Hyperledger/Firebase simulation acceptable.

---

## **5. Partnership APIs**

For food delivery apps, retailers, schools, hospitals:

* API endpoints like

  * `/submitDish`
  * `/getOilScore`
  * `/getCertifiedOptions`

These **Partnership APIs** exist to let **external organizations** (restaurants, schools, food delivery apps, hospitals, retailers, etc.) connect their systems to **your platform** and exchange data in a structured way.

#  **What Each API Does (Purpose Explained)**

---

## **1. `/submitDish` — For Restaurants, Canteens & Food Manufacturers**

### **Purpose**

Allows external partners to **upload dish details**, such as:

* ingredients
* oil used per serving
* cooking method
* nutrition
* cuisine

### **Why it's needed**

Your platform can’t manually add thousands of dishes.
This endpoint lets partners **automate the submission** of menu items to your database.

### **Example**

Swiggy restaurant calls:

```
POST /submitDish
{
  "restaurantId": "R129",
  "dishName": "Paneer Butter Masala",
  "oilUsed": "45 ml",
  "ingredients": ["paneer", "cream", "tomato", "oil"],
  "servingSize": 250
}
```

Your system receives it → calculates score → stores → shows in app.

---

## **2. `/getOilScore` — For Menu Labeling**

### **Purpose**

Returns your platform’s **standardized oil health score** for a dish.

### **Why it's needed**

Food delivery apps want to show things like:

* “Low Oil”
* “Healthy Choice”
* “Oil Score: 7/10”

This endpoint lets them get that score **in real-time**.

### **Example**

Zomato calls:

```
GET /getOilScore?dishId=12345
```

Your API responds:

```
{
  "dishId": 12345,
  "oilScore": 7,
  "category": "Green – Low Oil"
}
```

Zomato shows it on their menu.

---

## **3. `/getCertifiedOptions` — For Displaying Healthy Items**

### **Purpose**

Returns a list of **certified low-oil dishes** from restaurants or kitchens.

### **Why it's needed**

Integrations want to show:

* “Healthy Options” filter
* “Low Oil Certified Restaurants”
* “Recommended for Hospitals / Schools”

### **Example**

A school MDM partner calls:

```
GET /getCertifiedOptions?district=Jaipur
```

Your platform responds:

```
[
  {
    "dishName": "Upma",
    "oilScore": 9,
    "institution": "Govt School #12"
  },
  ...
]
```

This promotes healthy, certified food choices.

---

## **6. Gamification & Rewards**

* Points for low-oil days.
* Levels, badges (e.g., "Oil Smart Champion").
* Leaderboards (school/community groups).
* Redeemable rewards (even simulated coupons).

---

## **7. Institutional Kitchen Monitoring**

Ideal for:

* Mid-Day Meal (MDM) scheme
* Hostels
* Hospitals
* Canteens

Features:

* Bulk oil usage logging
* Alerts when exceeding limits
* Daily reports
* Supervisor dashboard

---

## **8. Advanced Analytics Dashboard**

* Predictive analytics (oil consumption trends).
* Compare states/districts.
* Identify high-risk clusters.
* Campaign effectiveness analysis.

---

#  **Layer 3 — Premium / Innovative Features (Bonus, Only If Time Allows)**

These impress judges but are not mandatory:

### 🔹 AR/VR cooking assistant

### 🔹 AI image recognition of food items (estimate oil content)

### 🔹 Integration with government health schemes

### 🔹 Offline mode for PWA

---

#  SUMMARY TABLE — Layered Feature Set

| Layer       | Features                                                                                                                      | Priority                    |
| ----------- | ----------------------------------------------------------------------------------------------------------------------------- | --------------------------- |
| **Layer 1** | Onboarding, Tracker, Awareness, Recipes, Nudges, Basic Dashboard                                                              | **Mandatory (MVP)**         |
| **Layer 2** | AI recommendations, IoT integration, Certification system, Blockchain, APIs, Rewards, Institutional tools, Advanced Dashboard | **High Value (For finals)** |
| **Layer 3** | AR/VR, AI food scanning, scheme integration, offline mode                                                                     | **Optional**                |

---

# New Features

## Simulated Smartwatch Integration

* Track calories burned, steps walked, and distance via simulated smartwatch API.
* Real-time or periodic sync from a simulated device.
* Users can view fitness activity and correlate it with oil consumption.

## Leaderboards

* **User Leaderboard:** Ranks users by lowest oil consumption.
* **Chef Leaderboard:** Ranks chefs by most liked low-oil recipes.
* Weekly/monthly filters, badges, and gamification.

## Simulated Oil Reusability Sensor

* IoT light-scattering sensor simulation returns oil quality metrics.
* Provides reusability score, safety recommendations, and raw sensor data.
* Automatically triggers alerts when oil becomes unsafe.
